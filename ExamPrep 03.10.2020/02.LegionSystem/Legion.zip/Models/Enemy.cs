﻿namespace _02.LegionSystem.Models
{
    using System;
    using _02.LegionSystem.Interfaces;

    public class Enemy : IEnemy
    {
        public Enemy(int attackSpeed, int health)
        {
            this.AttackSpeed = attackSpeed;
            this.Health = health;
        }

        public int AttackSpeed { get; set; }

        public int Health { get; set; }

        public int CompareTo(object obj)
        {
            if (obj.Equals(1))
            {
                return 1;
            }
            else if (obj.Equals(0))
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
    }
}
